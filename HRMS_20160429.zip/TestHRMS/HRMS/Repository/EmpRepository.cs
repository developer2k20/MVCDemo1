﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using HRMS.Models;
using System.Configuration;

namespace HRMS.Repository
{
    public class EmpRepository
    {
        private SqlConnection con;
        //To Handle connection related activities
        private void connection()
        {
            string constr = ConfigurationManager.ConnectionStrings["getconn"].ToString();
            con = new SqlConnection(constr);
        }

        public List<EmployeeModel> GetAllEmployees()
        {
            connection();
            List<EmployeeModel> EmpList = new List<EmployeeModel>();
            string strSql = "select isnull(emp.EmpId, 0)as EmpId, isnull(emp.EmpName, '')as EmpName, isnull(emp.Email, '')as Email, isnull(st.StateName, '')as [State], ISNULL(emp.City, '')as City, isnull(emp.ZipCode, '') as ZipCode, convert(nvarchar(10), CreatedOn, 101)as StartDate, case Deactive when 0 then 'True' else 'False' end as Active from Employee emp left outer join States st on st.id = emp.State";
            SqlCommand com = new SqlCommand(strSql, con);
            com.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();

            //Bind EmpModel generic list using LINQ 
            EmpList = (from DataRow dr in dt.Rows

                       select new EmployeeModel()
                       {
                           EmpId = Convert.ToInt32(dr["EmpId"]),
                           EmpName = Convert.ToString(dr["EmpName"]),
                           Email = Convert.ToString(dr["Email"]),
                           City = Convert.ToString(dr["City"]),
                           State = Convert.ToString(dr["State"]),
                           ZipCode = Convert.ToString(dr["ZipCode"]),
                           CreatedOn = Convert.ToString(dr["StartDate"]),
                           ActiveStatus = Convert.ToString(dr["Active"])
                       }).ToList();


            return EmpList;


        }

        public List<EmployeeModel> GetSearchedEmployees(string EmployeeName, string status, int UserId)
        {
            //connection();
            List<EmployeeModel> EmpList = new List<EmployeeModel>();
            //string strSql = "select isnull(emp.EmpId, 0)as EmpId, isnull(emp.EmpName, '')as EmpName, isnull(emp.Email, '')as Email, isnull(st.StateName, '')as [State], ISNULL(emp.City, '')as City, isnull(emp.ZipCode, '') as ZipCode, convert(nvarchar(10), CreatedOn, 101)as StartDate, case Deactive when 0 then 'True' else 'False' end as Active from Employee emp left outer join States st on st.id = emp.State where 1=1";
            //if (EmployeeName != "" && EmployeeName != null)
            //{
            //    strSql = strSql + " and emp.EmpName like '%" + EmployeeName.Replace("'", "''") + "%'";
            //}
            //if (status != "" && status != null)
            //{
            //    strSql = strSql + " and deactive = " + status;
            //}
            //SqlCommand com = new SqlCommand(strSql, con);
            //com.CommandType = CommandType.Text;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //con.Open();
            //da.Fill(dt);
            //con.Close();

            ////Bind EmpModel generic list using LINQ 
            //EmpList = (from DataRow dr in dt.Rows

            //           select new EmployeeModel()
            //           {
            //               EmpId = Convert.ToInt32(dr["EmpId"]),
            //               EmpName = Convert.ToString(dr["EmpName"]),
            //               Email = Convert.ToString(dr["Email"]),
            //               City = Convert.ToString(dr["City"]),
            //               State = Convert.ToString(dr["State"]),
            //               ZipCode = Convert.ToString(dr["ZipCode"]),
            //               CreatedOn = Convert.ToString(dr["StartDate"]),
            //               ActiveStatus = Convert.ToString(dr["Active"])
            //           }).ToList();


            //return EmpList;

            HRMSEntities db = new HRMSEntities();

            var query = (from c in db.Employees
                         //join r in db.States on c.State equals r.id.ToString()
                         join r in db.Cities on c.City equals r.id.ToString()
                         where c.CreatedBy == UserId
                         orderby c.EmpId
                         select new EmployeeModel { EmpId = c.EmpId, EmpName = c.EmpName, Email = c.Email, City = r.CityName, ZipCode = c.ZipCode, Date = (DateTime)c.CreatedOn, ActiveStatus = c.Deactive == true ? "False" : "True" });

            if (EmployeeName != "" && EmployeeName != null)
            {
                query = query.Where(u => u.EmpName.Contains(EmployeeName));
            }

            /*if (status != "" && status != null)
            {
                //bool deact = false;
                //if (status == "0")
                //{
                //    deact = false;
                //}
                //else
                //{
                //    deact = true;
                //}
                query = query.Where(u => u.Deactive == false);
            }*/

            EmpList = query.ToList();

            return EmpList;
        }

        public bool CheckDuplicateEmailId(string EmpId, string Email)
        {
            //connection();
            bool RetValue = false;
            //string strSql = "select EmpId from Employee where Email = '" + Email + "' and Deactive = 0 and EmpId <> " + EmpId;
            //SqlCommand com = new SqlCommand(strSql, con);
            //com.CommandType = CommandType.Text;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //con.Open();
            //da.Fill(dt);
            //con.Close();

            //if (dt != null)
            //{
            //    if (dt.Rows.Count > 0)
            //    {
            //        RetValue = true;
            //    }
            //}

            HRMSEntities db = new HRMSEntities();

            var query = (from c in db.Employees
                         where c.Email == Email && c.Deactive == false && c.EmpId.ToString() != EmpId
                         select c);

            int count = query.Count();

            if (count > 0)
            {
                RetValue = true;
            }

            return RetValue;
        }

        public bool CheckDuplicateEmpSalary(string SalId, string EmpId, string year,string month)
        {
            //connection();
            bool RetValue = false;
            //string strSql = "select * from EmpSalary where EmpId = " + EmpId + " and SalaryMonth = " + month + " and SalaryYear = " + year + " and id <> " + SalId;
            //SqlCommand com = new SqlCommand(strSql, con);
            //com.CommandType = CommandType.Text;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //con.Open();
            //da.Fill(dt);
            //con.Close();

            //if (dt != null)
            //{
            //    if (dt.Rows.Count > 0)
            //    {
            //        RetValue = true;
            //    }
            //}

            HRMSEntities db = new HRMSEntities();

            var query = (from c in db.EmpSalaries
                         where c.EmpId.ToString() == EmpId && c.SalaryMonth.ToString() == month && c.SalaryYear.ToString() == year && c.id.ToString() != SalId
                         select c);

            int count = query.Count();

            if (count > 0)
            {
                RetValue = true;
            }

            return RetValue;
        }

        public EmployeeModel GetSingleEmployeeOnId(string EmpId)
        {
            //connection();
            List<EmployeeModel> EmpList = new List<EmployeeModel>();
            //string strSql = "select * from Employee where EmpId = " + EmpId;
            //SqlCommand com = new SqlCommand(strSql, con);
            //com.CommandType = CommandType.Text;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //con.Open();
            //da.Fill(dt);
            //con.Close();

            ////Bind EmpModel generic list using LINQ 
            //EmpList = (from DataRow dr in dt.Rows

            //           select new EmployeeModel()
            //           {
            //               EmpId = Convert.ToInt32(dr["EmpId"]),
            //               EmpName = Convert.ToString(dr["EmpName"]),
            //               Email = Convert.ToString(dr["Email"]),
            //               City = Convert.ToString(dr["City"]),
            //               State = Convert.ToString(dr["State"]),
            //               ZipCode = Convert.ToString(dr["ZipCode"]),
            //               Deactive = Convert.ToBoolean(dr["Deactive"]),
            //               Address = Convert.ToString(dr["Address"])
            //           }).ToList();

            HRMSEntities db = new HRMSEntities();

            Employee emp = (from c in db.Employees
                        where c.EmpId.ToString() == EmpId
                        select c).ToList().FirstOrDefault();

            bool IsUser1 = CheckIsEmployeeUser((int)emp.UserId);

            var query = (from c in db.Employees
                         where c.EmpId.ToString() == EmpId
                         select new EmployeeModel { EmpId = c.EmpId, EmpName = c.EmpName, Email = c.Email, City = c.City, State = c.State, ZipCode = c.ZipCode, Deactive = (bool)c.Deactive, Address = c.Address, IsUser = IsUser1, UserId = (int)c.UserId });

            EmpList = query.ToList();

            return EmpList.FirstOrDefault();
        }

        private bool CheckIsEmployeeUser(int UserId)
        {
            bool IsUser = false;

            if (UserId == 0)
                IsUser = false;
            else
            {
                HRMSEntities db = new HRMSEntities();

                return db.Users.Any(c => c.id == UserId && c.IsActive == true);
            }

            return IsUser;
        }

        public bool EmployeeAddEdit(EmployeeModel obj, string CallType, int EnteredBy)
        {
            //connection();
            //SqlCommand com = new SqlCommand("sp_ManageEmployee", con);
            //com.CommandType = CommandType.StoredProcedure;
            //com.Parameters.AddWithValue("@EmpId", obj.EmpId);
            //com.Parameters.AddWithValue("@EmpName", obj.EmpName);
            //com.Parameters.AddWithValue("@Email", obj.Email);
            //com.Parameters.AddWithValue("@State", obj.State);
            //com.Parameters.AddWithValue("@City", obj.City);
            //com.Parameters.AddWithValue("@Address", obj.Address);
            //com.Parameters.AddWithValue("@ZipCode", obj.ZipCode);
            //com.Parameters.AddWithValue("@Deactive", obj.Deactive);
            //com.Parameters.AddWithValue("@CallType", CallType);

            int i = 0;

            if (CallType == "insert")
            {
                HRMSEntities db = new HRMSEntities();
                Employee emp = new Employee();

                if (obj.IsUser)
                {
                    string UserName = obj.EmpName.Trim();
                    string TrimmedUserName = "";
                    bool isSpace = false;

                    for (var iloop = 0; iloop < UserName.Length; iloop++)
                    {
                        if (UserName[iloop].ToString() == " ")
                            isSpace = true;
                        else
                            TrimmedUserName = TrimmedUserName + UserName[iloop].ToString();
                    }

                    User usr = new User();
                    usr.UserName = TrimmedUserName;
                    usr.Password = TrimmedUserName;
                    usr.FirstName = Convert.ToString(UserName.Split(' ')[0]);
                    if (isSpace)
                        usr.LastName = Convert.ToString(UserName.Split(' ')[1]);
                    else
                        usr.LastName = "";
                    usr.Email = obj.Email;
                    usr.Gender = null;
                    usr.CityId = Convert.ToInt32(obj.City);
                    usr.IsActive = true;
                    usr.CreatedOn = DateTime.Now;

                    db.Users.Add(usr);
                    db.SaveChanges();

                    emp.UserId = usr.id;
                }
                else
                {
                    emp.UserId = 0;
                }
                
                emp.EmpName = obj.EmpName;
                emp.Email = obj.Email;
                emp.State = "";
                emp.City = obj.City;
                if (obj.Address == null)
                    emp.Address = "";
                else
                    emp.Address = obj.Address;
                if (obj.ZipCode == null)
                    emp.ZipCode = "";
                else
                    emp.ZipCode = obj.ZipCode;
                emp.Deactive = false;
                emp.CreatedOn = DateTime.Now;
                emp.CreatedBy = EnteredBy;

                db.Employees.Add(emp);
                db.SaveChanges();

                i = 1;
            }
            if (CallType == "update")
            {
                HRMSEntities db = new HRMSEntities();
                Employee emp = db.Employees.Where(c => c.EmpId == obj.EmpId).FirstOrDefault();

                if (emp.UserId == 0)
                {
                    if (obj.IsUser)
                    {
                        string UserName = obj.EmpName.Trim();
                        string TrimmedUserName = "";
                        bool isSpace = false;

                        for (var iloop = 0; iloop < UserName.Length; iloop++)
                        {
                            if (UserName[iloop].ToString() == " ")
                                isSpace = true;
                            else
                                TrimmedUserName = TrimmedUserName + UserName[iloop].ToString();
                        }

                        User usr = new User();
                        usr.UserName = TrimmedUserName;
                        usr.Password = TrimmedUserName;
                        usr.FirstName = Convert.ToString(UserName.Split(' ')[0]);
                        if (isSpace)
                            usr.LastName = Convert.ToString(UserName.Split(' ')[1]);
                        else
                            usr.LastName = "";
                        usr.Email = obj.Email;
                        usr.Gender = null;
                        usr.CityId = Convert.ToInt32(obj.City);
                        usr.IsActive = true;
                        usr.CreatedOn = DateTime.Now;

                        db.Users.Add(usr);
                        db.SaveChanges();

                        emp.UserId = usr.id;
                    }
                }
                else
                {
                    User usr = db.Users.Where(c => c.id == obj.UserId).FirstOrDefault();

                    if (obj.IsUser)
                        usr.IsActive = true;
                    else
                        usr.IsActive = false;
                    usr.ModifiedOn = DateTime.Now;

                    db.SaveChanges();
                }

                emp.EmpName = obj.EmpName;
                emp.Email = obj.Email;
                emp.State = "";
                emp.City = obj.City;
                if (obj.Address == null)
                    emp.Address = "";
                else
                    emp.Address = obj.Address;
                if (obj.ZipCode == null)
                    emp.ZipCode = "";
                else
                    emp.ZipCode = obj.ZipCode;
                emp.Deactive = obj.Deactive;
                emp.ModifiedOn = DateTime.Now;
                emp.ModifiedBy = EnteredBy;

                db.SaveChanges();
                i = 1;
            }

            //con.Open();
            //int i = com.ExecuteNonQuery();
            //con.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<EmpSalaryModel> GetEmpSalaryList(string EmpId, string SalaryYear, string SalaryMonth)
        {
            //connection();
            List<EmpSalaryModel> EmpSalList = new List<EmpSalaryModel>();
            //string strSql = "select * from EmpSalary where EmpId = " + EmpId;

            //if (SalaryYear != "")
            //{
            //    strSql = strSql + " and SalaryYear = " + SalaryYear;
            //}

            //if (SalaryMonth != "")
            //{
            //    strSql = strSql + " and SalaryMonth = " + SalaryMonth;
            //}

            //strSql = strSql + " order by SalaryYear desc, SalaryMonth desc";

            //SqlCommand com = new SqlCommand(strSql, con);
            //com.CommandType = CommandType.Text;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //con.Open();
            //da.Fill(dt);
            //con.Close();

            ////Bind EmpModel generic list using LINQ 
            //EmpSalList = (from DataRow dr in dt.Rows

            //              select new EmpSalaryModel()
            //              {
            //                  id = Convert.ToInt32(dr["id"]),
            //                  Salary = Convert.ToInt32(dr["Salary"]),
            //                  SalaryMonth = Convert.ToInt32(dr["SalaryMonth"]),
            //                  SalaryYear = Convert.ToInt32(dr["SalaryYear"])
            //              }).ToList();

            HRMSEntities db = new HRMSEntities();

            var query = (from c in db.EmpSalaries
                         where c.EmpId.ToString() == EmpId
                         orderby c.SalaryYear descending, c.SalaryMonth descending
                         select new EmpSalaryModel { id = c.id, Salary = (int)c.Salary, SalaryMonth = (int)c.SalaryMonth, SalaryYear = (int)c.SalaryYear });

            if (SalaryYear != "")
            {
                query = query.Where(u => u.SalaryYear.ToString() == SalaryYear);
            }

            if (SalaryMonth != "")
            {
                query = query.Where(u => u.SalaryMonth.ToString() == SalaryMonth);
            }

            EmpSalList = query.ToList();

            return EmpSalList;
        }

        public bool EmployeeSalaryAddEdit(EmpSalaryModel obj, string CallType)
        {
            HRMSEntities db = new HRMSEntities();
            int i = 0;
            /*connection();
            SqlCommand com = new SqlCommand("sp_ManageEmpSalary", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@id", obj.id);
            com.Parameters.AddWithValue("@EmpId", obj.EmpId);
            com.Parameters.AddWithValue("@Salary", obj.Salary);
            com.Parameters.AddWithValue("@SalaryMonth", obj.SalaryMonth);
            com.Parameters.AddWithValue("@SalaryYear", obj.SalaryYear);
            com.Parameters.AddWithValue("@CallType", CallType);

            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {

                return true;

            }
            else
            {

                return false;
            }*/
            if (CallType == "insert")
            {
                EmpSalary empSal = new EmpSalary();

                empSal.EmpId = obj.EmpId;
                empSal.Salary = obj.Salary;
                empSal.SalaryMonth = obj.SalaryMonth;
                empSal.SalaryYear = obj.SalaryYear;

                db.EmpSalaries.Add(empSal);
                db.SaveChanges();

                i = 1;
            }
            else if (CallType == "update")
            {
                EmpSalary empSal = db.EmpSalaries.Where(c => c.id == obj.id).FirstOrDefault();

                empSal.EmpId = obj.EmpId;
                empSal.Salary = obj.Salary;
                empSal.SalaryMonth = obj.SalaryMonth;
                empSal.SalaryYear = obj.SalaryYear;

                db.SaveChanges();

                i = 1;
            }
            else if (CallType == "delete")
            {
                EmpSalary empSal = db.EmpSalaries.Where(c => c.id == obj.id).FirstOrDefault();

                db.EmpSalaries.Remove(empSal);
                db.SaveChanges();

                i = 1;
            }

            if (i >= 1)
                return true;
            else
                return false;
        }

        public EmpSalaryModel GetSingleEmployeeSalaryOnId(string id)
        {
            //connection();
            List<EmpSalaryModel> EmpSalList = new List<EmpSalaryModel>();
            //string strSql = "select * from EmpSalary where id = " + id;
            //SqlCommand com = new SqlCommand(strSql, con);
            //com.CommandType = CommandType.Text;
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //con.Open();
            //da.Fill(dt);
            //con.Close();

            ////Bind EmpModel generic list using LINQ 
            //EmpSalList = (from DataRow dr in dt.Rows

            //              select new EmpSalaryModel()
            //              {
            //                  id = Convert.ToInt32(dr["id"]),
            //                  EmpId = Convert.ToInt32(dr["EmpId"]),
            //                  Salary = Convert.ToInt32(dr["Salary"]),
            //                  SalaryMonth = Convert.ToInt32(dr["SalaryMonth"]),
            //                  SalaryYear = Convert.ToInt32(dr["SalaryYear"])
            //              }).ToList();

            HRMSEntities db = new HRMSEntities();

            var query = (from c in db.EmpSalaries
                         where c.id.ToString() == id
                         select new EmpSalaryModel { id = c.id, EmpId = (int)c.EmpId, Salary = (int)c.Salary, SalaryMonth = (int)c.SalaryMonth, SalaryYear = (int)c.SalaryYear });

            EmpSalList = query.ToList();

            return EmpSalList.FirstOrDefault();
        }
    }
}