﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HRMS.Models;

namespace HRMS.Repository
{
    public class CityRepository
    {
        HRMSEntities db = new HRMSEntities();

        public List<CityModel> GetAllCities()
        {
            return db.Cities.OrderBy(c => c.CityName).Select(x => new CityModel { id = x.id, CityName = x.CityName }).ToList();
        }
    }
}