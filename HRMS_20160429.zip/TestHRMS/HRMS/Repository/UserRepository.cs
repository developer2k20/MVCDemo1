﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HRMS.Models;

namespace HRMS.Repository
{
    public class UserRepository
    {
        HRMSEntities db = new HRMSEntities();

        public UserModel CheckUserLogin(string UserName, string Password)
        {
            return db.Users.Where(u => u.UserName == UserName && u.Password == Password).Select(x => new UserModel { id = x.id, IsActive = (bool)x.IsActive, Password = x.Password }).ToList().FirstOrDefault();
        }

        public bool CheckDuplicateUserName(string UserName)
        {
            return db.Users.Any(u => u.UserName == UserName);
        }

        public bool UserAddEdit(UserModel obj, string CallType)
        {
            bool UserEntry = false;

            if (CallType == "insert")
            {
                User usr = new User();
                usr.UserName = obj.UserName;
                usr.Password = obj.Password;
                usr.FirstName = obj.FirstName;
                usr.LastName = obj.LastName;
                usr.Email = obj.Email;
                usr.Gender = obj.Gender;
                usr.CityId = obj.CityId;
                usr.IsActive = true;
                usr.CreatedOn = DateTime.Now;

                db.Users.Add(usr);
                db.SaveChanges();

                UserEntry = true;
            }
            if (CallType == "update")
            {
                User usr = db.Users.Where(u => u.id == obj.id).FirstOrDefault();
                usr.FirstName = obj.FirstName;
                usr.LastName = obj.LastName;
                usr.Email = obj.Email;
                usr.Gender = obj.Gender;
                usr.CityId = obj.CityId;
                usr.ModifiedOn = DateTime.Now;

                db.SaveChanges();

                UserEntry = true;
            }
            if (CallType == "changepassword")
            {
                User usr = db.Users.Where(u => u.id == obj.id).FirstOrDefault();
                usr.Password = obj.Password;
                usr.ModifiedOn = DateTime.Now;

                db.SaveChanges();

                UserEntry = true;
            }

            return UserEntry;
        }

        public UserModel GetSingleUserOnId(string UserId)
        {
            return db.Users.Where(u => u.id.ToString() == UserId).Select(x => new UserModel { UserName = x.UserName, Password = x.Password, FirstName = x.FirstName, LastName = x.LastName, Email = x.Email, Gender = x.Gender, CityId = x.CityId == null ? 0 : (int)x.CityId }).ToList().FirstOrDefault();
        }

        public UserModel CheckValidOldPassword(string id, string password)
        {
            return db.Users.Where(u => u.id.ToString() == id && u.Password == password).Select(x => new UserModel { Password = x.Password }).ToList().FirstOrDefault();
        }
    }
}