﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HRMS.Repository;
using HRMS.Models;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace HRMS.Controllers
{
    public class AccountController : Controller
    {
        //
        // GET: /Account/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            /*ModelState.Clear();

            string UserName = Request.Form["UserName"];
            string Password = Request.Form["Password"];

            ViewBag.Title = "HRMS - User Login";
            string name = ViewBag.ErrorMessage;
            string name1 = ViewBag.Message;

            if (UserName != null && UserName.Trim() != "" && Password != null && Password != "")
            {
                UserRepository ur = new UserRepository();

                bool ValidUser = ur.CheckUserLogin(UserName, Password);

                if (ValidUser)
                    return RedirectToAction("GetAllEmpDetails", "Index");

                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Invalid user name or password!";
            }*/
            ViewBag.Title = "HRMS - User Login";
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginModel login)
        {
            ModelState.Clear();

            ViewBag.Title = "HRMS - User Login";

            if (login.UserName != null && login.UserName.Trim() != "")
            {
                UserRepository ur = new UserRepository();

                UserModel usr = ur.CheckUserLogin(login.UserName, login.Password);
                bool IsActive = true;
                /*if (UserId > 0)
                    return RedirectToAction("GetAllEmpDetails", "Index");*/
                if (usr != null)
                {
                    if (usr.id != null)
                    {
                        if (IsNumeric(usr.id))
                        {
                            IsActive = usr.IsActive;
                            if (login.Password == usr.Password)
                            {
                                if (IsActive)
                                {
                                    Session["UserId"] = usr.id;
                                    return RedirectToAction("GetAllEmpDetails", "Index");
                                }
                            }
                            //return RedirectToAction("Home");    
                        }
                    }
                }

                if (IsActive)
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Invalid user name or password!";
                }
                else
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Sorry you do not have rights to acccess this site!";
                }
            }

            return View();
        }

        private static bool IsNumeric(object Expression)
        {
            double retNum;

            bool isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        public ActionResult Dummy()
        {
            return PartialView();
        }

        public ActionResult Home()
        {
            if (Session["UserId"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Home";

            return View();
        }

        [HttpGet]
        public ActionResult AddUser()
        {
            CityRepository cities = new CityRepository();
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";
            return View();
        }

        [HttpGet]
        public ActionResult UserProfile()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            UserRepository usr = new UserRepository();
            ModelState.Clear();

            CityRepository cities = new CityRepository();
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - User Profile";
            return View(usr.GetSingleUserOnId(Session["UserId"].ToString()));
        }

        [HttpPost]
        public ActionResult UserProfile(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            ViewBag.Title = "HRMS - User Profile";
            UserRepository usrRep = new UserRepository();

            usr.id = (int)Session["UserId"];

            if (usrRep.UserAddEdit(usr, "update"))
            {
                TempData["Message"] = "User updated successfully.";
                TempData["ErrorMessage"] = "";
            }
            else
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "System error. Please try again!";
            }

            CityRepository cities = new CityRepository();
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            return View(usrRep.GetSingleUserOnId(Session["UserId"].ToString()));
        }

        [HttpPost]
        public ActionResult AddUser(UserModel usr)
        {
            ModelState.Clear();

            //string UserName = Request.Form["UserName"];
            //string Email = Request.Form["Email"];

            ViewBag.Title = "HRMS - Add User";

            if (usr.UserName != null && usr.UserName.Trim() != "")
            {
                //usr.Password = "admin1";
                //SmtpClient sc = new SmtpClient();
                //sc.Host = "127.0.0.1";
                //StringBuilder sb = new StringBuilder();

                //var ss = RenderRazorViewToString("UserMailTemplate", usr);

                //sb.Append("<h3>Login Credentials</h3>");
                //sb.Append("<hr />");
                //sb.Append("<b>User Name:</b> " + UserName);
                //sb.Append("<b>Password:</b> ChangeIt123");

                //var mail = new MailMessage("developer.2k20@gmail.com", Email)
                //{
                //    Subject = "Login Credentials",
                //    Body = sb.ToString()
                //};

                //sc.Send(mail);

                UserRepository usrRep = new UserRepository();

                if (usrRep.UserAddEdit(usr, "insert"))
                {
                    TempData["Message"] = "User added successfully.";
                    TempData["ErrorMessage"] = "";

                    return RedirectToAction("Login");
                }
            }

            TempData["Message"] = "";
            TempData["ErrorMessage"] = "System error. Please try again!";

            return View();
        }

        public ActionResult CheckUserName(string UserName)
        {
            UserRepository usr = new UserRepository();

            bool RetValue = usr.CheckDuplicateUserName(UserName);

            return Json(!RetValue, JsonRequestBehavior.AllowGet);
        }


        private string RenderRazorViewToString(string viewName, object model)
        {
            ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                var viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        public ActionResult ChangePassword()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Change Password";
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel obj)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            if (obj.NewPassword == obj.OldPassword)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Old and New Password cannot be same!";
            }
            else if (obj.NewPassword != obj.ConfirmNewPassword)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "New and Confirm password must be same!";
            }
            else if (obj.NewPassword.Length < 6)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "New password should be at least 6 characters long!";
            }
            else
            {
                UserRepository usrRep = new UserRepository();
                UserModel usr = usrRep.CheckValidOldPassword(Convert.ToString(Session["UserId"]), obj.OldPassword);
                bool ValidUser = false;

                if (usr != null)
                {
                    if (obj.OldPassword == usr.Password)
                    {
                        ValidUser = true;
                    }
                }

                if (ValidUser)
                {
                    usr.id = Convert.ToInt32(Session["UserId"]);
                    usr.Password = obj.NewPassword;

                    if (usrRep.UserAddEdit(usr, "changepassword"))
                    {
                        TempData["Message"] = "Password changed successfully!";
                        TempData["ErrorMessage"] = "";
                    }
                    else
                    {
                        TempData["Message"] = "";
                        TempData["ErrorMessage"] = "System error. Please try again!";
                    }
                }
                else
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Invalid old password!";
                }
            }
            

            ViewBag.Title = "HRMS - Change Password";
            return View();
        }
    }
}
