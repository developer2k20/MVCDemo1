﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRMS.Models
{
    public class CityModel
    {
        public int id { get; set; }

        public string CityName { get; set; }
    }
}