﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRMS.Models
{
    public class UserQualificationModel
    {
        public int id { get; set; }

        public int UserId { get; set; }

        public int QualificationId { get; set; }

        public enum QualificationType : int { PartTime, FullTime };
    }
}