﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HRMSRepository;
using HRMSModels.Models;

namespace HRMS.Controllers
{
    public class IndexController : Controller
    {
        //
        // GET: /Index to Check/by shiv

        static readonly ICityRepository cities = new CityRepository();
        static readonly IEmpRepository er = new EmpRepository();
        static readonly IUserRepository usr = new UserRepository();
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetAllEmpDetails(string SearchEmployee, string Status)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            //EmpRepository empRo = new EmpRepository();
            ModelState.Clear();

            bool SearchCriteria = false;
            //string SearchEmployee = Request.Form["txtEmployee"];
            //string Status = Request.Form["cmbStatus"];
            string just = Request.Form["cmbStatus"];

            if (!string.IsNullOrEmpty(SearchEmployee))
            {
                if (SearchEmployee.Trim() != "")
                {
                    SearchCriteria = true;
                }
            }

            if (!string.IsNullOrEmpty(Status))
            {
                SearchCriteria = true;
            }
            else
            {
                Status = "0";
                //SearchCriteria = true;
            }

            ViewBag.Title = "HRMS - Employee List";
            
            if (SearchCriteria)
            {
                return PartialView("_employeelist", er.GetSearchedEmployees(SearchEmployee, Status, Convert.ToInt32(Session["UserId"])));
            }
            else
            {
                return PartialView(er.GetSearchedEmployees(SearchEmployee, Status, Convert.ToInt32(Session["UserId"])));
            }
        }

        public ActionResult AddEmployee()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }
            
            //CityRepository cities = new CityRepository();
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            //StateRepository sr = new StateRepository();
            //var sel = new SelectList(sr.GetAllStates(), "id", "StateName");
            ViewBag.Title = "HRMS - Add Employee";
            //ViewBag.StateList = sel.ToList();

            return View();
        }

        [HttpPost]
        [ActionName("AddEmployee")]
        public ActionResult AddEmployee1(EmployeeModel emp)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            /*EmployeeModel Emp = new EmployeeModel();
            Emp.EmpId = 0;
            Emp.EmpName = Request.Form["EmpName"];
            Emp.Email = Request.Form["Email"];
            Emp.State = "";
            Emp.City = Request.Form["City"];
            Emp.ZipCode = Request.Form["ZipCode"];
            Emp.Address = Request.Form["Address"];
            Emp.Deactive = false;
            Emp.IsUser = Convert.ToBoolean(Request.Form["IsUser"]);*/

            try
            {
                bool DuplicateEmail = false;
                bool DuplicateUser = false;
                if (ModelState.IsValid)
                {
                    //EmpRepository EmpRepo = new EmpRepository();
                    /*if (emp.IsUser)
                    {
                        //UserRepository usr = new UserRepository();
                        string UserName = emp.EmpName.Trim();
                        string TrimmedUserName = "";

                        for (var iloop = 0; iloop < UserName.Length; iloop++)
                        {
                            if (UserName[iloop].ToString() != " ")
                            {
                                TrimmedUserName = TrimmedUserName + UserName[iloop].ToString();
                            }
                        }

                        if (usr.CheckDuplicateUserName(TrimmedUserName))
                        {
                            DuplicateUser = true;
                        }
                    }*/
                    
                    if(!DuplicateUser)
                    {
                        if (er.CheckDuplicateEmailId(emp.EmpId.ToString(), emp.Email.ToString()))
                        {
                            DuplicateEmail = true;
                        }
                        else
                        {
                            if (er.EmployeeAddEdit(emp, "insert", Convert.ToInt32(Session["UserId"])))
                            {
                                return RedirectToAction("GetAllEmpDetails");
                            }
                        }
                    }
                }

                if (DuplicateUser)
                {
                    ViewBag.ErrorMessage = "Duplicate user name!";
                }
                else if (DuplicateEmail)
                {
                    ViewBag.ErrorMessage = "Duplicate email!";
                }
                else
                {
                    ViewBag.ErrorMessage = "System error. Please try again!";
                }
                ViewBag.Message = "";

                //CityRepository cities = new CityRepository();
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();

                //StateRepository sr = new StateRepository();
                //var sel = new SelectList(sr.GetAllStates(), "id", "StateName");
                ViewBag.Title = "HRMS - Add Employee";
                //ViewBag.StateList = sel.ToList();
            }
            catch
            {
                ViewBag.ErrorMessage = "System error. Please try again!";
                ViewBag.Message = "";

                //CityRepository cities = new CityRepository();
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();

                //StateRepository sr = new StateRepository();
                //var sel = new SelectList(sr.GetAllStates(), "id", "StateName");
                ViewBag.Title = "HRMS - Add Employee";
                //ViewBag.StateList = sel.ToList();
            }

            return View(emp);
        }

        public ActionResult EditEmployee(string id)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            //EmpRepository empRo = new EmpRepository();
            ModelState.Clear();

            //CityRepository cities = new CityRepository();
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            //StateRepository sr = new StateRepository();
            //var sel = new SelectList(sr.GetAllStates(), "id", "StateName");
            ViewBag.Title = "HRMS - Edit Employee";
            //ViewBag.StateList = sel.ToList();

            return View(er.GetSingleEmployeeOnId(id));
        }

        [HttpPost]
        [ActionName("EditEmployee")]
        public ActionResult EditEmployee1(EmployeeModel emp)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            /*EmployeeModel Emp = new EmployeeModel();
            Emp.EmpId = Convert.ToInt32(Request.Form["EmpId"]);
            Emp.EmpName = Request.Form["EmpName"];
            Emp.Email = Request.Form["Email"];
            Emp.State = "";
            Emp.City = Request.Form["City"];
            Emp.ZipCode = Request.Form["ZipCode"];
            Emp.Address = Request.Form["Address"];
            if (Request.Form["Deactive"].Contains("true"))
            {
                Emp.Deactive = true;
            }
            else
            {
                Emp.Deactive = false;
            }*/

            try
            {
                bool DuplicateEmail = false;
                bool DuplicateUser = false;
                if (ModelState.IsValid)
                {
                    //EmpRepository EmpRepo = new EmpRepository();
                    if (emp.UserId == 0)
                    {
                        if (emp.IsUser)
                        {
                            //UserRepository usr = new UserRepository();
                            string UserName = emp.EmpName.Trim();
                            string TrimmedUserName = "";

                            for (var iloop = 0; iloop < UserName.Length; iloop++)
                            {
                                if (UserName[iloop].ToString() != " ")
                                {
                                    TrimmedUserName = TrimmedUserName + UserName[iloop].ToString();
                                }
                            }

                            if (usr.CheckDuplicateUserName(TrimmedUserName))
                            {
                                DuplicateUser = true;
                            }
                        }
                    }

                    if (!DuplicateUser)
                    {
                        if (er.CheckDuplicateEmailId(emp.EmpId.ToString(), emp.Email.ToString()))
                        {
                            DuplicateEmail = true;
                        }
                        else
                        {
                            if (er.EmployeeAddEdit(emp, "update", Convert.ToInt32(Session["UserId"])))
                            {
                                return RedirectToAction("GetAllEmpDetails");
                            }
                        }
                    }

                    emp = er.GetSingleEmployeeOnId(emp.EmpId.ToString());
                }
                if (DuplicateUser)
                    ViewBag.ErrorMessage = "Duplicate user name!";
                else if (DuplicateEmail)
                    ViewBag.ErrorMessage = "Duplicate email!";
                else
                    ViewBag.ErrorMessage = "System error. Please try again!";
                ViewBag.Message = "";

                //CityRepository cities = new CityRepository();
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();

                //StateRepository sr = new StateRepository();
                //var sel = new SelectList(sr.GetAllStates(), "id", "StateName");
                ViewBag.Title = "HRMS";
                //ViewBag.StateList = sel.ToList();
            }
            catch
            {
                ViewBag.ErrorMessage = "System error. Please try again!";
                ViewBag.Message = "";

                //CityRepository cities = new CityRepository();
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();

                //StateRepository sr = new StateRepository();
                //var sel = new SelectList(sr.GetAllStates(), "id", "StateName");
                ViewBag.Title = "HRMS";
                //ViewBag.StateList = sel.ToList();
            }

            return View(emp);
        }

        //[HttpPost]
        public ActionResult EmployeeSalaryList(string id, string SalaryYear, string SalaryMonth)
        {
            bool SearchCriteria = true;

            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            if (id == null)
            {
                id = Request.Form["EmpId"];
            }
            if (SalaryYear == null)
            {
                SearchCriteria = false;
                SalaryYear = "";
            }

            if (SalaryMonth == null)
                SalaryMonth = "";

            //EmpRepository empRo = new EmpRepository();
            ModelState.Clear();

            ViewData["EmpId"] = id;

            ViewBag.Title = "HRMS - Employee Salary List";
            //EmpRepository empRep = new EmpRepository();
            EmployeeModel emp = er.GetSingleEmployeeOnId(id);

            @ViewBag.EmpName = emp.EmpName + " (#" + emp.EmpId.ToString() + ")";

            if (SearchCriteria)
            {
                return PartialView("_employeesalarylist", er.GetEmpSalaryList(id, SalaryYear, SalaryMonth));
            }
            else
            {
                return View(er.GetEmpSalaryList(id, SalaryYear, SalaryMonth));
            }
        }

        public ActionResult AddEmployeeSalary(string EmpId)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Add Employee Salary";
            //EmpRepository empRep = new EmpRepository();
            EmployeeModel emp = er.GetSingleEmployeeOnId(EmpId);

            @ViewBag.EmpName = emp.EmpName + " (#" + emp.EmpId.ToString() + ")";

            return View();
        }

        public ActionResult EditEmployeeSalary(string id)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Edit Employee Salary";
            //EmpRepository empRo = new EmpRepository();
            ModelState.Clear();

            //EmpRepository empRep = new EmpRepository();
            EmpSalaryModel empSal = er.GetSingleEmployeeSalaryOnId(id);
            string empid = Convert.ToString(empSal.EmpId);

            EmployeeModel emp = er.GetSingleEmployeeOnId(empid);

            @ViewBag.EmpName = emp.EmpName + " (#" + emp.EmpId.ToString() + ")";
            @ViewBag.EmpId = emp.EmpId.ToString();
            @ViewBag.SalMonth = empSal.SalaryMonth;

            return View(er.GetSingleEmployeeSalaryOnId(id));
        }

        public ActionResult DeleteEmployeeSalary(string id)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            //EmpRepository empRep = new EmpRepository();
            EmpSalaryModel EmpSal = er.GetSingleEmployeeSalaryOnId(id);

            if (er.EmployeeSalaryAddEdit(EmpSal, "delete"))
            {
                return RedirectToAction("EmployeeSalaryList", new { id = EmpSal.EmpId });
            }
            else
            {
                return RedirectToAction("EmployeeSalaryList", new { id = EmpSal.EmpId });
            }
        }

        [HttpPost]
        [ActionName("AddEmployeeSalary")]
        public ActionResult AddEmployeeSalary1(EmpSalaryModel EmpSal)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            /*EmpSalaryModel EmpSal = new EmpSalaryModel();
            EmpSal.EmpId = Convert.ToInt32(Request.Form["EmpId"]);
            EmpSal.Salary = Convert.ToInt32(Request.Form["Salary"]);
            EmpSal.SalaryYear = Convert.ToInt32(Request.Form["SalaryYear"]);
            EmpSal.SalaryMonth = Convert.ToInt32(Request.Form["SalaryMonth"]);*/

            try
            {
                bool DuplicateSalary = false;
                if (ModelState.IsValid)
                {
                    //EmpRepository EmpRepo = new EmpRepository();
                    if (er.CheckDuplicateEmpSalary(EmpSal.id.ToString(),EmpSal.EmpId.ToString(),EmpSal.SalaryYear.ToString(),EmpSal.SalaryMonth.ToString()))
                    {
                        DuplicateSalary = true;
                    }
                    else
                    {
                        if (er.EmployeeSalaryAddEdit(EmpSal, "insert"))
                        {
                            return RedirectToAction("EmployeeSalaryList", new { id = EmpSal.EmpId });
                        }
                    }
                }

                if (DuplicateSalary)
                {
                    ViewBag.ErrorMessage = "Salary is already entered for " + MonthName(EmpSal.SalaryMonth) + ", " + EmpSal.SalaryYear + " for this employee!";
                }
                else
                {
                    ViewBag.ErrorMessage = "System error. Please try again!";
                }
                ViewBag.Message = "";
            }
            catch
            {
                ViewBag.ErrorMessage = "System error. Please try again!";
                ViewBag.Message = "";
            }

            ViewBag.Title = "HRMS - Add Employee Salary";
            //EmpRepository empRep = new EmpRepository();
            EmployeeModel emp = er.GetSingleEmployeeOnId(EmpSal.EmpId.ToString());

            @ViewBag.EmpName = emp.EmpName + " (#" + emp.EmpId.ToString() + ")";

            return View();
        }

        [HttpPost]
        [ActionName("EditEmployeeSalary")]
        public ActionResult EditEmployeeSalary1()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            EmpSalaryModel EmpSal = new EmpSalaryModel();
            EmpSal.id = Convert.ToInt32(Request.Form["id"]);
            EmpSal.EmpId = Convert.ToInt32(Request.Form["EmpId"]);
            EmpSal.Salary = Convert.ToInt32(Request.Form["Salary"]);
            EmpSal.SalaryYear = Convert.ToInt32(Request.Form["SalaryYear"]);
            EmpSal.SalaryMonth = Convert.ToInt32(Request.Form["SalaryMonth"]);

            try
            {
                bool DuplicateSalary = false;
                if (ModelState.IsValid)
                {
                    //EmpRepository EmpRepo = new EmpRepository();
                    if (er.CheckDuplicateEmpSalary(EmpSal.id.ToString(), EmpSal.EmpId.ToString(), EmpSal.SalaryYear.ToString(), EmpSal.SalaryMonth.ToString()))
                    {
                        DuplicateSalary = true;
                    }
                    else
                    {
                        if (er.EmployeeSalaryAddEdit(EmpSal, "update"))
                        {
                            return RedirectToAction("EmployeeSalaryList", new { id = EmpSal.EmpId });
                        }
                    }
                }

                if (DuplicateSalary)
                {
                    ViewBag.ErrorMessage = "Salary is already entered for " + MonthName(EmpSal.SalaryMonth) + ", " + EmpSal.SalaryYear + " for this employee!";
                }
                else
                {
                    ViewBag.ErrorMessage = "System error. Please try again!";
                }
                ViewBag.Message = "";
            }
            catch
            {
                ViewBag.ErrorMessage = "System error. Please try again!";
                ViewBag.Message = "";
            }

            ViewBag.Title = "HRMS - Edit Employee Salary";
            //EmpRepository empRep = new EmpRepository();
            EmployeeModel emp = er.GetSingleEmployeeOnId(EmpSal.EmpId.ToString());

            @ViewBag.EmpName = emp.EmpName + " (#" + emp.EmpId.ToString() + ")";
            EmpSal = er.GetSingleEmployeeSalaryOnId(Convert.ToString(EmpSal.id));
            @ViewBag.SalMonth = EmpSal.SalaryMonth;
            @ViewBag.EmpId = emp.EmpId.ToString();

            return View(EmpSal);
        }

        public ActionResult ShowMonth(string Year)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            List<SelectListItem> lst = new List<SelectListItem>();

            int CurrentYear = DateTime.Now.Year;
            int MaxCount = 12;

            if (CurrentYear.ToString() == Year)
                MaxCount = DateTime.Now.Month - 1;

            for (int iloop = 1; iloop <= MaxCount; iloop++)
            {
                lst.Add(new SelectListItem
                {
                    Text = MonthName(iloop),
                    Value = iloop.ToString()
                });
            }

            return Json(lst, JsonRequestBehavior.AllowGet);
        }

        private string MonthName(int Month)
        {
            string mName = "";
            if (Month == 1)
                mName = "January";
            else if (Month == 2)
                mName = "February";
            else if (Month == 3)
                mName = "March";
            else if (Month == 4)
                mName = "April";
            else if (Month == 5)
                mName = "May";
            else if (Month == 6)
                mName = "June";
            else if (Month == 7)
                mName = "July";
            else if (Month == 8)
                mName = "August";
            else if (Month == 9)
                mName = "September";
            else if (Month == 10)
                mName = "October";
            else if (Month == 11)
                mName = "November";
            else if (Month == 12)
                mName = "December";

            return mName;
        }

        public ActionResult Logout()
        {
            Session["UserId"] = null;
            Session["UserName"] = null;
            Session["IsAdmin"] = null;
            Session.Abandon();

            return RedirectToAction("Login", "Account");
        }
    }
}
