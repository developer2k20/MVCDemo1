﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.IO;
using HRMSRepository;
using HRMSModels.Models;
using System.ComponentModel.DataAnnotations;
using aspNetMX;
using System.Web.Security;

namespace HRMS.Controllers
{
    public class AccountController : Controller
    {
        //
        // GET: /Account/
        static readonly ICityRepository cities = new CityRepository();
        static readonly IUserRepository ur = new UserRepository();
        
        private static readonly ApiHandler api = new ApiHandler();

        /*[HttpGet]
        public CustomerViewModel Search()
        {
           
            string result = api.GetCall("Search", "Customers/Customer");
            customer = (CustomerViewModel)Newtonsoft.Json.JsonConvert.DeserializeObject(result, typeof(CustomerViewModel));
            if (customer != null)
            {
                return customer;
            }
            return null;
        }*/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            ViewBag.Title = "HRMS - User Login";
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginModel login)
        {
            ModelState.Clear();

            ViewBag.Title = "HRMS - User Login";

            if (login.UserName != null && login.UserName.Trim() != "")
            {
                UserModel usr = ur.CheckUserLogin(login.UserName, login.Password);
                bool Deactive = false;
                
                if (usr != null)
                {
                    if (usr.id != null)
                    {
                        if (IsNumeric(usr.id))
                        {
                            Deactive = usr.Deactive;
                            if (login.Password == usr.Password)
                            {
                                if (!Deactive)
                                {
                                    Session["UserId"] = usr.id;
                                    string UserId = usr.id.ToString();
                                    
                                    string gender = usr.Gender;
                                    
                                    if (gender == "mr")
                                        gender = "Mr. ";
                                    else if (gender == "ms")
                                        gender = "Ms. ";

                                    if (usr.IsAdmin)
                                        Session["UserName"] = gender + usr.FirstName + " " + usr.LastName + " (Admin)";
                                    else
                                        Session["UserName"] = gender + usr.FirstName + " " + usr.LastName;

                                    Session["IsAdmin"] = usr.IsAdmin;

                                    FormsAuthentication.SetAuthCookie(UserId, false);
                                    return RedirectToAction("Home");
                                }
                            }
                            //return RedirectToAction("Home");    
                        }
                    }
                }

                if (!Deactive)
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Invalid user name or password!";
                }
                else
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Sorry you do not have rights to access this site!";
                }
            }

            return View();
        }

        private static bool IsNumeric(object Expression)
        {
            double retNum;

            bool isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        public ActionResult Dummy()
        {
            return PartialView();
        }

        public ActionResult Home()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Home";

            return View();
        }

        [HttpGet]
        public ActionResult AddUser()
        {
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";
            return View();
        }

        [HttpGet]
        public ActionResult UserProfile()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - User Profile";

            return View(ur.GetSingleUserOnId(Session["UserId"].ToString()));
        }

        [HttpPost]
        public ActionResult UserProfile(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            ViewBag.Title = "HRMS - User Profile";
            
            usr.id = (int)Session["UserId"];
            usr.ModifiedBy = (int)Session["UserId"];

            if (ur.UserAddEdit(usr, "update"))
            {
                TempData["Message"] = "User updated successfully.";
                TempData["ErrorMessage"] = "";
            }
            else
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "System error. Please try again!";
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            return View(ur.GetSingleUserOnId(Session["UserId"].ToString()));
        }

        [HttpPost]
        public ActionResult AddUser(UserModel usr)
        {
            ModelState.Clear();

            if (usr.UserName != null && usr.UserName.Trim() != "")
            {
                if (ur.UserAddEdit(usr, "insert"))
                {
                    TempData["Message"] = "User added successfully.";
                    TempData["ErrorMessage"] = "";

                    return RedirectToAction("Login");
                }
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";

            TempData["Message"] = "";
            TempData["ErrorMessage"] = "System error. Please try again!";

            return View();
        }

        public ActionResult CheckUserName(string UserName)
        {
            bool RetValue = ur.CheckDuplicateUserName(UserName);

            return Json(!RetValue, JsonRequestBehavior.AllowGet);
        }

        private string RenderRazorViewToString(string viewName, object model)
        {
            ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                var viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        public ActionResult ChangePassword()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Change Password";
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel obj)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            if (obj.NewPassword == obj.OldPassword)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Old and New Password cannot be same!";
            }
            else if (obj.NewPassword != obj.ConfirmNewPassword)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "New and Confirm password must be same!";
            }
            else if (obj.NewPassword.Length < 6)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "New password should be at least 6 characters long!";
            }
            else
            {
                UserModel usr = ur.CheckValidOldPassword(Convert.ToString(Session["UserId"]), obj.OldPassword);
                bool ValidUser = false;

                if (usr != null)
                {
                    if (obj.OldPassword == usr.Password)
                    {
                        ValidUser = true;
                    }
                }

                if (ValidUser)
                {
                    usr.id = Convert.ToInt32(Session["UserId"]);
                    usr.Password = obj.NewPassword;
                    usr.ModifiedBy = Convert.ToInt32(Session["UserId"]);

                    if (ur.UserAddEdit(usr, "changepassword"))
                    {
                        TempData["Message"] = "Password changed successfully!";
                        TempData["ErrorMessage"] = "";
                    }
                    else
                    {
                        TempData["Message"] = "";
                        TempData["ErrorMessage"] = "System error. Please try again!";
                    }
                }
                else
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Invalid old password!";
                }
            }

            ViewBag.Title = "HRMS - Change Password";
            return View();
        }

        [HttpGet]
        public ActionResult GetAllUsers(string ActiveStatus, string FirstName, string LastName)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            bool SearchCriteria = false;

            if (ActiveStatus == null)
                ActiveStatus = "0";
            else
                SearchCriteria = true;

            ViewBag.Title = "HRMS - User List";

            if (SearchCriteria)
                return PartialView("_userlist", ur.GetSearchUser(ActiveStatus, FirstName, LastName));
            else
                return View(ur.GetSearchUser(ActiveStatus, FirstName, LastName));
        }

        [HttpGet]
        public ActionResult AddNewUser()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";
            return View();
        }

        [HttpPost]
        public ActionResult AddNewUser(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            if (usr.UserName != null && usr.UserName.Trim() != "")
            {
                usr.CreatedBy = Convert.ToInt32(Session["UserId"]);
                if (ur.UserAddEdit(usr, "insert"))
                {
                    return RedirectToAction("GetAllUsers");
                }
            }

            //bool blnValue = IsValidEmail(usr.Email);

            ViewBag.Message = "";
            ViewBag.ErrorMessage = "System error. Please try again!";

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";

            return View();
        }

        private bool IsValidEmail(string EmailId)
        {
            /*string key = "QER5N-C9DCL-5B3VP-EQR9M-YPR41-AEYA4-4QY5L-3721C-VGKRC-RU7XS-XK6JY-6JT5Y-DKY3";
            MXValidate.LoadLicenseKey(key);*/
            MXValidate mx = new MXValidate();

            mx.LogInMemory = true;

            mx.SMTPFrom = "sanjeevarora30@gmail.com";
            mx.SMTPHello = "mail.google.com";
            MXValidateLevel level = mx.Validate(EmailId, aspNetMX.MXValidateLevel.Mailbox);

            if (level == aspNetMX.MXValidateLevel.Mailbox)
                return true;
            else
                return false;
        }

        [HttpGet]
        public ActionResult EditUser(string id)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }
                
            ModelState.Clear();

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - User Profile";

            return View(ur.GetSingleUserOnId(id));
        }

        [HttpPost]
        public ActionResult EditUser(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            ViewBag.Title = "HRMS - Edit User";

            usr.ModifiedBy = (int)Session["UserId"];

            bool blnValue = IsValidEmail(usr.Email);

            if (ur.UserAddEdit(usr, "update"))
            {
                /*TempData["Message"] = "User updated successfully.";
                TempData["ErrorMessage"] = "";*/

                return RedirectToAction("GetAllUsers");
            }
            TempData["Message"] = "";
            TempData["ErrorMessage"] = "System error. Please try again!";

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            return View(ur.GetSingleUserOnId(Convert.ToString(usr.id)));
        }
    }
}
