﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Script.Serialization;
using System.Configuration;

namespace HRMS
{
    public class ApiHandler : HttpClient
    {
        // <add key="ApiBaseURL" value="http://localhost:63868/" />


        #region
        private string baseAddress = string.Empty;

        #endregion

        #region "ApiHandler Constructor "
        public ApiHandler()
        {
            baseAddress = ConfigurationManager.AppSettings["ApiBaseURL"];
            BaseAddress = new Uri(baseAddress);

        }
        #endregion

        public string GetCall(string action, string controller, string active, string contactname, int LoggedUserId)
        {
            string result = string.Empty;
            try
            {
                using (ApiHandler api = new ApiHandler())
                {
                    HttpResponseMessage response = api.GetAsync("api/" + controller + "/" + action + "?active=" + active + "&contactname=" + contactname + "&LoggedUserId=" + LoggedUserId).Result;
                    var jsonResult = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result = jsonResult;
                    }
                    else
                    {
                        throw new Exception((string)Newtonsoft.Json.JsonConvert.DeserializeObject(jsonResult, typeof(string)));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public string GetDuplicateCompany(string action, string controller, string CompanyName, string CustomerId)
        {
            string result = string.Empty;
            try
            {
                using (ApiHandler api = new ApiHandler())
                {
                    HttpResponseMessage response = api.GetAsync("api/" + controller + "/" + action + "?CompanyName=" + CompanyName + "&CustomerId=" + CustomerId).Result;
                    var jsonResult = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result = jsonResult;
                    }
                    else
                    {
                        throw new Exception((string)Newtonsoft.Json.JsonConvert.DeserializeObject(jsonResult, typeof(string)));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public string PostCall(string apiPath, string jsonData)
        {
            try
            {
                using (ApiHandler api = new ApiHandler())
                {
                    var httpContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
                    var response = api.PostAsync(apiPath, httpContent).Result;
                    var result = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        return result;
                    }
                    else
                    {
                        throw new Exception((string)Newtonsoft.Json.JsonConvert.DeserializeObject(result, typeof(string)));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public string PutCall(string apiPath, string jsonData)
        {
            try
            {
                using (ApiHandler api = new ApiHandler())
                {
                    var httpContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
                    var response = api.PutAsync(apiPath, httpContent).Result;
                    var result = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        return result;
                    }
                    else
                    {
                        throw new Exception((string)Newtonsoft.Json.JsonConvert.DeserializeObject(result, typeof(string)));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public string GetCustomer(string action, string controller, string CustomerId)
        {
            string result = string.Empty;
            try
            {
                using (ApiHandler api = new ApiHandler())
                {
                    HttpResponseMessage response = api.GetAsync("api/" + controller + "/" + action + "?CustomerId=" + CustomerId).Result;
                    var jsonResult = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result = jsonResult;
                    }
                    else
                    {
                        throw new Exception((string)Newtonsoft.Json.JsonConvert.DeserializeObject(jsonResult, typeof(string)));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }
}



