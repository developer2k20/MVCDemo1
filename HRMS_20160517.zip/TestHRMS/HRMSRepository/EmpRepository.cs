﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;
using HRMSData;
using System.Web;

namespace HRMSRepository
{
    public class EmpRepository: IEmpRepository
    {
        HRMSEntities db = new HRMSEntities();
        public List<EmployeeModel> GetSearchedEmployees(string EmployeeName, string status, int UserId)
        {
            List<EmployeeModel> EmpList = new List<EmployeeModel>();

            bool deact = false;
            if (status == "0")
                deact = false;
            else
                deact = true;

            var query = (from c in db.Employees
                         join r in db.Cities on c.City equals r.id.ToString()
                         where c.Deactive == deact
                         orderby c.EmpId
                         select new EmployeeModel { EmpId = c.EmpId, EmpName = c.EmpName, Email = c.Email, City = r.CityName, ZipCode = c.ZipCode, Date = (DateTime)c.CreatedOn, ActiveStatus = c.Deactive == true ? "False" : "True", CreatedBy = (int)c.CreatedBy });

            if (EmployeeName != "" && EmployeeName != null)
            {
                query = query.Where(u => u.EmpName.Contains(EmployeeName));
            }
            
            if (!Convert.ToBoolean(HttpContext.Current.Session["IsAdmin"]))
            {
                query = query.Where(x => x.CreatedBy == UserId);
            }

            EmpList = query.ToList();

            return EmpList;
        }

        public bool CheckDuplicateEmailId(string EmpId, string Email)
        {
            bool RetValue = false;

            var query = (from c in db.Employees
                         where c.Email == Email && c.Deactive == false && c.EmpId.ToString() != EmpId
                         select c);

            int count = query.Count();

            if (count > 0)
            {
                RetValue = true;
            }

            return RetValue;
        }

        public bool CheckDuplicateEmpSalary(string SalId, string EmpId, string year, string month)
        {
            bool RetValue = false;

            var query = (from c in db.EmpSalaries
                         where c.EmpId.ToString() == EmpId && c.SalaryMonth.ToString() == month && c.SalaryYear.ToString() == year && c.id.ToString() != SalId
                         select c);

            int count = query.Count();

            if (count > 0)
            {
                RetValue = true;
            }

            return RetValue;
        }

        public EmployeeModel GetSingleEmployeeOnId(string EmpId)
        {
            List<EmployeeModel> EmpList = new List<EmployeeModel>();

            HRMSData.Employee emp = (from c in db.Employees
                                     where c.EmpId.ToString() == EmpId
                                     select c).ToList().FirstOrDefault();

            bool IsUser1 = CheckIsEmployeeUser((int)emp.UserId);

            var query = (from c in db.Employees
                         where c.EmpId.ToString() == EmpId
                         select new EmployeeModel { EmpId = c.EmpId, EmpName = c.EmpName, Email = c.Email, City = c.City, State = c.State, ZipCode = c.ZipCode, Deactive = (bool)c.Deactive, Address = c.Address, IsUser = IsUser1, UserId = (int)c.UserId });

            EmpList = query.ToList();

            return EmpList.FirstOrDefault();
        }

        public bool CheckIsEmployeeUser(int UserId)
        {
            bool IsUser = false;

            if (UserId == 0)
                IsUser = false;
            else
            {
                return db.Users.Any(c => c.id == UserId && c.IsActive == true);
            }

            return IsUser;
        }

        public bool EmployeeAddEdit(EmployeeModel obj, string CallType, int EnteredBy)
        {
            int i = 0;

            if (CallType == "insert")
            {
                Employee emp = new Employee();

                /*if (obj.IsUser)
                {
                    string UserName = obj.EmpName.Trim();
                    string TrimmedUserName = "";
                    bool isSpace = false;

                    for (var iloop = 0; iloop < UserName.Length; iloop++)
                    {
                        if (UserName[iloop].ToString() == " ")
                            isSpace = true;
                        else
                            TrimmedUserName = TrimmedUserName + UserName[iloop].ToString();
                    }

                    HRMSData.User usr = new HRMSData.User();
                    usr.UserName = TrimmedUserName;
                    usr.Password = TrimmedUserName;
                    usr.FirstName = Convert.ToString(UserName.Split(' ')[0]);
                    if (isSpace)
                        usr.LastName = Convert.ToString(UserName.Split(' ')[1]);
                    else
                        usr.LastName = "";
                    usr.Email = obj.Email;
                    usr.Gender = null;
                    usr.CityId = Convert.ToInt32(obj.City);
                    usr.IsActive = true;
                    usr.CreatedOn = DateTime.Now;

                    db.Users.Add(usr);
                    db.SaveChanges();

                    emp.UserId = usr.id;
                }
                else
                {
                    emp.UserId = 0;
                }*/

                emp.EmpName = obj.EmpName;
                emp.Email = obj.Email;
                emp.State = "";
                emp.City = obj.City;
                if (obj.Address == null)
                    emp.Address = "";
                else
                    emp.Address = obj.Address;
                if (obj.ZipCode == null)
                    emp.ZipCode = "";
                else
                    emp.ZipCode = obj.ZipCode;
                emp.Deactive = false;
                emp.CreatedOn = DateTime.Now;
                emp.CreatedBy = EnteredBy;
                emp.UserId = 0;

                db.Employees.Add(emp);
                db.SaveChanges();

                i = 1;
            }
            if (CallType == "update")
            {
                Employee emp = db.Employees.Where(c => c.EmpId == obj.EmpId).FirstOrDefault();

                /*if (emp.UserId == 0)
                {
                    if (obj.IsUser)
                    {
                        string UserName = obj.EmpName.Trim();
                        string TrimmedUserName = "";
                        bool isSpace = false;

                        for (var iloop = 0; iloop < UserName.Length; iloop++)
                        {
                            if (UserName[iloop].ToString() == " ")
                                isSpace = true;
                            else
                                TrimmedUserName = TrimmedUserName + UserName[iloop].ToString();
                        }

                        HRMSData.User usr = new HRMSData.User();
                        usr.UserName = TrimmedUserName;
                        usr.Password = TrimmedUserName;
                        usr.FirstName = Convert.ToString(UserName.Split(' ')[0]);
                        if (isSpace)
                            usr.LastName = Convert.ToString(UserName.Split(' ')[1]);
                        else
                            usr.LastName = "";
                        usr.Email = obj.Email;
                        usr.Gender = null;
                        usr.CityId = Convert.ToInt32(obj.City);
                        usr.IsActive = true;
                        usr.CreatedOn = DateTime.Now;

                        db.Users.Add(usr);
                        db.SaveChanges();

                        emp.UserId = usr.id;
                    }
                }
                else
                {
                    HRMSData.User usr = db.Users.Where(c => c.id == obj.UserId).FirstOrDefault();

                    if (obj.IsUser)
                        usr.IsActive = true;
                    else
                        usr.IsActive = false;
                    usr.ModifiedOn = DateTime.Now;

                    db.SaveChanges();
                }*/

                emp.EmpName = obj.EmpName;
                emp.Email = obj.Email;
                emp.State = "";
                emp.City = obj.City;
                if (obj.Address == null)
                    emp.Address = "";
                else
                    emp.Address = obj.Address;
                if (obj.ZipCode == null)
                    emp.ZipCode = "";
                else
                    emp.ZipCode = obj.ZipCode;
                emp.Deactive = obj.Deactive;
                emp.ModifiedOn = DateTime.Now;
                emp.ModifiedBy = EnteredBy;

                db.SaveChanges();
                i = 1;
            }

            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<EmpSalaryModel> GetEmpSalaryList(string EmpId, string SalaryYear, string SalaryMonth)
        {
            List<EmpSalaryModel> EmpSalList = new List<EmpSalaryModel>();

            var query = (from c in db.EmpSalaries
                         where c.EmpId.ToString() == EmpId
                         orderby c.SalaryYear descending, c.SalaryMonth descending
                         select new EmpSalaryModel { id = c.id, Salary = (int)c.Salary, SalaryMonth = (int)c.SalaryMonth, SalaryYear = (int)c.SalaryYear });

            if (SalaryYear != "")
            {
                query = query.Where(u => u.SalaryYear.ToString() == SalaryYear);
            }

            if (SalaryMonth != "")
            {
                query = query.Where(u => u.SalaryMonth.ToString() == SalaryMonth);
            }

            EmpSalList = query.ToList();

            return EmpSalList;
        }

        public bool EmployeeSalaryAddEdit(EmpSalaryModel obj, string CallType)
        {
            int i = 0;

            if (CallType == "insert")
            {
                HRMSData.EmpSalary empSal = new HRMSData.EmpSalary();

                empSal.EmpId = obj.EmpId;
                empSal.Salary = obj.Salary;
                empSal.SalaryMonth = obj.SalaryMonth;
                empSal.SalaryYear = obj.SalaryYear;

                db.EmpSalaries.Add(empSal);
                db.SaveChanges();

                i = 1;
            }
            else if (CallType == "update")
            {
                HRMSData.EmpSalary empSal = db.EmpSalaries.Where(c => c.id == obj.id).FirstOrDefault();

                empSal.EmpId = obj.EmpId;
                empSal.Salary = obj.Salary;
                empSal.SalaryMonth = obj.SalaryMonth;
                empSal.SalaryYear = obj.SalaryYear;

                db.SaveChanges();

                i = 1;
            }
            else if (CallType == "delete")
            {
                HRMSData.EmpSalary empSal = db.EmpSalaries.Where(c => c.id == obj.id).FirstOrDefault();

                db.EmpSalaries.Remove(empSal);
                db.SaveChanges();

                i = 1;
            }

            if (i >= 1)
                return true;
            else
                return false;
        }

        public EmpSalaryModel GetSingleEmployeeSalaryOnId(string id)
        {
            List<EmpSalaryModel> EmpSalList = new List<EmpSalaryModel>();

            var query = (from c in db.EmpSalaries
                         where c.id.ToString() == id
                         select new EmpSalaryModel { id = c.id, EmpId = (int)c.EmpId, Salary = (int)c.Salary, SalaryMonth = (int)c.SalaryMonth, SalaryYear = (int)c.SalaryYear });

            EmpSalList = query.ToList();

            return EmpSalList.FirstOrDefault();
        }
    }
}
