﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;
using HRMSData;

namespace HRMSRepository
{
    public class CityRepository: ICityRepository
    {
        HRMSEntities db = new HRMSEntities();

        public List<CityModel> GetAllCities()
        {
            return db.Cities.OrderBy(c => c.CityName).Select(x => new CityModel { id = x.id, CityName = x.CityName }).ToList();
        }
    }
}
