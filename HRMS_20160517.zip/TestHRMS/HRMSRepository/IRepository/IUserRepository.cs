﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;

namespace HRMSRepository
{
    public interface IUserRepository
    {
        UserModel CheckUserLogin(string UserName, string Password);
        bool CheckDuplicateUserName(string UserName);
        bool UserAddEdit(UserModel obj, string CallType);
        UserModel GetSingleUserOnId(string UserId);
        UserModel CheckValidOldPassword(string id, string password);
        UserModel CheckLoggedUserIsAdmin(int LoggedUserId);
        List<UserModel> GetSearchUser(string status, string FirstName, string LastName);
    }
}
