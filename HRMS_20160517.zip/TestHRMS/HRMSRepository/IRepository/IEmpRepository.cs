﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;

namespace HRMSRepository
{
    public interface IEmpRepository
    {
        List<EmployeeModel> GetSearchedEmployees(string EmployeeName, string status, int UserId);
        bool CheckDuplicateEmailId(string EmpId, string Email);
        bool CheckDuplicateEmpSalary(string SalId, string EmpId, string year, string month);
        EmployeeModel GetSingleEmployeeOnId(string EmpId);
        bool CheckIsEmployeeUser(int UserId);
        bool EmployeeAddEdit(EmployeeModel obj, string CallType, int EnteredBy);
        List<EmpSalaryModel> GetEmpSalaryList(string EmpId, string SalaryYear, string SalaryMonth);
        bool EmployeeSalaryAddEdit(EmpSalaryModel obj, string CallType);
        EmpSalaryModel GetSingleEmployeeSalaryOnId(string id);
    }
}
