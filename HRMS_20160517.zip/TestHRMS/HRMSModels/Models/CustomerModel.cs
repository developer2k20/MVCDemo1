﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace HRMSModels.Models
{
    public class CustomerModel
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "Company Name is required.")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Contact Name is required.")]
        public string ContactName { get; set; }

        [Required(ErrorMessage = "Contact Title is required.")]
        public string ContactTitle { get; set; }

        [Display(Name = "City")]
        public int CityId { get; set; }

        public string CityName { get; set; }

        [Required(ErrorMessage = "Phone Number is required.")]
        [RegularExpression("([1-9][0-9]*)", ErrorMessage = "Invalid phone number.")]
        public string PhoneNumber { get; set; }

        public int CreatedBy { get; set; }

        public int ModifiedBy { get; set; }

        public bool deactive { get; set; }

        public string ActiveStatus { get; set; }

        public DateTime Date { get; set; }
        public string DisplayedDate
        {
            get
            {
                return Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
        }

        public string DealsIn { get; set; }
    }
}
